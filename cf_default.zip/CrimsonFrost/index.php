<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <title>Placeholder</title>
</head>
<body>
    <?php include('functions/accountbar.php')?>
    <?php include('functions/navbar.php')?>
    <main>
        <h1>&#8594; CONTENT WILL BE PLACED HERE &#8592;</h1>
        <h1>&#8594; CONTENT WILL BE PLACED HERE &#8592;</h1>
        <h1>&#8594; CONTENT WILL BE PLACED HERE &#8592;</h1>
        <h1>&#8594; CONTENT WILL BE PLACED HERE &#8592;</h1>
        <h1>&#8594; CONTENT WILL BE PLACED HERE &#8592;</h1>
        <h1>&#8594; CONTENT WILL BE PLACED HERE &#8592;</h1>
        <h1>&#8594; CONTENT WILL BE PLACED HERE &#8592;</h1>
        <h1>&#8594; CONTENT WILL BE PLACED HERE &#8592;</h1>
        <h1>&#8594; CONTENT WILL BE PLACED HERE &#8592;</h1>
        <h1>&#8594; CONTENT WILL BE PLACED HERE &#8592;</h1>
        <h1>&#8594; CONTENT WILL BE PLACED HERE &#8592;</h1>
        <h1>&#8594; CONTENT WILL BE PLACED HERE &#8592;</h1>
    </main>
<?php include('functions/footer.php')?>
</body>
</html>