<footer>
    <div class="footer-container prevent-select">
        <div class="footer-row">
            <div class="footer-col">
                <h4>Placeholder</h4>
                <ul>
                    <li><a href="#">About us</a></li>
                    <li><a href="#">Webshop</a></li>
                    <li><a href="#">Privacy Policy</a></li>
                </ul>
            </div>
            <div class="footer-col">
                <h4>Get Help</h4>
                <ul>
                    <li><a href="#">FAQ</a></li>
                    <li><a href="#">Shipping</a></li>
                    <li><a href="#">Returns</a></li>
                    <li><a href="#">Order Status</a></li>
                    <li><a href="#">Payment Options</a></li>
                </ul>
            </div>
            <div class="footer-col">
                <h4>Online Shop</h4>
                <ul>
                    <li><a href="#">Women</a></li>
                    <li><a href="#">Man</a></li>
                    <li><a href="#">Kids</a></li>
                    <li><a href="#">Home</a></li>
                </ul>
            </div>
            <div class="footer-col">
                <h4>Follow Us</h4>
                <div class="social-links">
                    <a href="#"><i class="fab fa-facebook-f"></i></a>
                    <a href="#"><i class="fab fa-twitter"></i></a>
                    <a href="#"><i class="fab fa-instagram"></i></a>
                    <a href="#"><i class="fab fa-linkedin-in"></i></a>
                </div>
            </div>
        </div>
        <p>&#169; 2024 Crimson Frost Inc. All Rights Reserved</p>
    </div>
</footer>