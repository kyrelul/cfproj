<div class="accountbar-container prevent-select">
    <div class="acc-left">
        <div><a href="#">Account Center</a></div>
    </div>
    <div class="acc-right">
        <div><a href="#">Bejelentkezés</a></div>
        <div><a href="#">Regisztráció</a></div>
    </div>
</div>
