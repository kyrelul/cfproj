<div class="navbar-container prevent-select">
    <div class="nav-logo">
        <div><a href="#">Placeholder</a></div>
    </div>
    <div class="nav-right">
        <div><a href="#">Page 1</a></div>
        <div><a href="#">Page 2</a></div>
        <div><a href="#">Page 3</a></div>
        <div><a href="#">Page 4</a></div>
        <div><a href="#">Page 5</a></div>
    </div>
</div>